package com.keyStone.Playroom021.repository;

import com.keyStone.Playroom021.entity.WorkOrderPart;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WorkOrderPartRepository extends JpaRepository<WorkOrderPart, Long> {
    List<WorkOrderPart> findByWorkOrderIdOrderByLoggedAtAsc(Long workOrderId);
}
