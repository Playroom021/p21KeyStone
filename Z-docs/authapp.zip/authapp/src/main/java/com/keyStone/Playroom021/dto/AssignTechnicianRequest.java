package com.keyStone.Playroom021.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AssignTechnicianRequest {

    @NotNull(message = "Technician is required")
    private Long technicianId;
}
