package com.keyStone.Playroom021.service;

import com.keyStone.Playroom021.dto.*;
import com.keyStone.Playroom021.entity.*;
import com.keyStone.Playroom021.repository.*;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * The dispatcher's view of the whole work-order board, across every customer.
 * Unlike CustomerPortalService (which scopes everything to one customer),
 * these methods are intentionally unscoped — a dispatcher needs to see and
 * route every job. Access to /api/dispatcher/** is what keeps this from being
 * reachable by anyone but a DISPATCHER (see SecurityConfig).
 */
@Service
@RequiredArgsConstructor
public class DispatcherService {

    private final CustomerRepository customerRepository;
    private final SiteRepository siteRepository;
    private final WorkOrderRepository workOrderRepository;
    private final WorkOrderStatusHistoryRepository historyRepository;
    private final UserRepository userRepository;

    // ---- Customers ----

    @Transactional
    public CustomerResponse createCustomer(CustomerRequest request) {
        Customer customer = customerRepository.save(Customer.builder()
                .companyName(request.getCompanyName().trim())
                .contactEmail(request.getContactEmail())
                .build());
        return toCustomerResponse(customer);
    }

    public List<CustomerResponse> listCustomers() {
        return customerRepository.findAllByOrderByCompanyNameAsc().stream()
                .map(this::toCustomerResponse)
                .toList();
    }

    private CustomerResponse toCustomerResponse(Customer c) {
        return CustomerResponse.builder()
                .id(c.getId())
                .companyName(c.getCompanyName())
                .contactEmail(c.getContactEmail())
                .build();
    }

    // ---- Sites ----

    @Transactional
    public SiteResponse createSite(DispatcherSiteRequest request) {
        Customer customer = customerRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new EntityNotFoundException("Customer not found"));
        Site site = Site.builder()
                .customer(customer)
                .name(request.getName().trim())
                .addressLine(request.getAddressLine())
                .city(request.getCity())
                .build();
        return toSiteResponse(siteRepository.save(site));
    }

    public List<SiteResponse> listSites() {
        return siteRepository.findAllByOrderByNameAsc().stream()
                .map(this::toSiteResponse)
                .toList();
    }

    private SiteResponse toSiteResponse(Site s) {
        return SiteResponse.builder()
                .id(s.getId())
                .name(s.getName())
                .addressLine(s.getAddressLine())
                .city(s.getCity())
                .customerId(s.getCustomer().getId())
                .customerName(s.getCustomer().getCompanyName())
                .build();
    }

    // ---- Technicians ----

    public List<TechnicianSummaryResponse> listTechnicians() {
        return userRepository.findByRoleOrderByFullNameAsc(Role.TECHNICIAN).stream()
                .map(t -> TechnicianSummaryResponse.builder()
                        .id(t.getId())
                        .fullName(t.getFullName())
                        .email(t.getEmail())
                        .phone(t.getPhone())
                        .build())
                .toList();
    }

    // ---- Work orders / board ----

    public List<BoardWorkOrderResponse> listBoard() {
        return workOrderRepository.findAllByOrderByCreatedAtDesc().stream()
                .map(this::toBoardResponse)
                .toList();
    }

    @Transactional
    public BoardWorkOrderResponse createWorkOrder(String actorEmail, WorkOrderCreateRequest request) {
        Customer customer = customerRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new EntityNotFoundException("Customer not found"));
        Site site = siteRepository.findByIdAndCustomerId(request.getSiteId(), customer.getId())
                .orElseThrow(() -> new EntityNotFoundException("Site not found for this customer"));

        User technician = null;
        if (request.getTechnicianId() != null) {
            technician = requireTechnician(request.getTechnicianId());
        }

        WorkOrder wo = WorkOrder.builder()
                .title(request.getTitle().trim())
                .description(request.getDescription())
                .customer(customer)
                .site(site)
                .priority(request.getPriority())
                .status(technician != null ? WorkOrderStatus.ASSIGNED : WorkOrderStatus.NEW)
                .assignedTechnician(technician)
                .slaDueAt(computeSlaDueAt(request.getPriority()))
                .build();

        wo = workOrderRepository.save(wo);
        wo.setCode("WO-" + (1000 + wo.getId()));
        wo = workOrderRepository.save(wo);

        historyRepository.save(WorkOrderStatusHistory.builder()
                .workOrder(wo)
                .fromStatus(null)
                .toStatus(wo.getStatus())
                .note(technician != null ? "Created by dispatcher and assigned to " + technician.getFullName()
                        : "Created by dispatcher")
                .changedByEmail(actorEmail)
                .changedByRole(Role.DISPATCHER.name())
                .build());

        return toBoardResponse(wo);
    }

    @Transactional
    public BoardWorkOrderResponse assignTechnician(String actorEmail, Long workOrderId, Long technicianId) {
        WorkOrder wo = requireWorkOrder(workOrderId);
        User technician = requireTechnician(technicianId);
        User previous = wo.getAssignedTechnician();

        wo.setAssignedTechnician(technician);
        WorkOrderStatus fromStatus = wo.getStatus();
        if (wo.getStatus() == WorkOrderStatus.NEW) {
            wo.setStatus(WorkOrderStatus.ASSIGNED);
        }
        wo = workOrderRepository.save(wo);

        String note = previous == null
                ? "Assigned to " + technician.getFullName()
                : "Reassigned from " + previous.getFullName() + " to " + technician.getFullName();
        historyRepository.save(WorkOrderStatusHistory.builder()
                .workOrder(wo)
                .fromStatus(fromStatus)
                .toStatus(wo.getStatus())
                .note(note)
                .changedByEmail(actorEmail)
                .changedByRole(Role.DISPATCHER.name())
                .build());

        return toBoardResponse(wo);
    }

    @Transactional
    public BoardWorkOrderResponse updateWorkOrder(String actorEmail, Long workOrderId, WorkOrderEditRequest request) {
        WorkOrder wo = requireWorkOrder(workOrderId);
        StringBuilder note = new StringBuilder();
        if (request.getTitle() != null && !request.getTitle().isBlank()) {
            wo.setTitle(request.getTitle().trim());
            note.append("Title updated. ");
        }
        if (request.getDescription() != null) {
            wo.setDescription(request.getDescription().isBlank() ? null : request.getDescription());
            note.append("Description updated.");
        }
        wo = workOrderRepository.save(wo);

        if (!note.isEmpty()) {
            historyRepository.save(WorkOrderStatusHistory.builder()
                    .workOrder(wo)
                    .fromStatus(wo.getStatus())
                    .toStatus(wo.getStatus())
                    .note(note.toString().trim())
                    .changedByEmail(actorEmail)
                    .changedByRole(Role.DISPATCHER.name())
                    .build());
        }

        return toBoardResponse(wo);
    }

    @Transactional
    public void deleteWorkOrder(Long workOrderId) {
        WorkOrder wo = requireWorkOrder(workOrderId);
        // Clear the append-only history first — FK from history -> work order would
        // otherwise block the delete.
        historyRepository.purgeByWorkOrderId(wo.getId());
        workOrderRepository.delete(wo);
    }

    private User requireTechnician(Long technicianId) {
        User user = userRepository.findById(technicianId)
                .orElseThrow(() -> new EntityNotFoundException("Technician not found"));
        if (user.getRole() != Role.TECHNICIAN) {
            throw new IllegalArgumentException("Selected user is not a technician");
        }
        return user;
    }

    private WorkOrder requireWorkOrder(Long id) {
        return workOrderRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Work order not found"));
    }

    private Instant computeSlaDueAt(Priority priority) {
        Instant now = Instant.now();
        return switch (priority) {
            case CRITICAL -> now.plus(4, ChronoUnit.HOURS);
            case HIGH -> now.plus(24, ChronoUnit.HOURS);
            case MEDIUM -> now.plus(48, ChronoUnit.HOURS);
            case LOW -> now.plus(72, ChronoUnit.HOURS);
        };
    }

    private BoardWorkOrderResponse toBoardResponse(WorkOrder wo) {
        User tech = wo.getAssignedTechnician();
        return BoardWorkOrderResponse.builder()
                .id(wo.getId())
                .code(wo.getCode())
                .title(wo.getTitle())
                .description(wo.getDescription())
                .customerId(wo.getCustomer().getId())
                .customerName(wo.getCustomer().getCompanyName())
                .siteId(wo.getSite().getId())
                .siteName(wo.getSite().getName())
                .priority(wo.getPriority().name())
                .status(wo.getStatus().name())
                .technicianId(tech != null ? tech.getId() : null)
                .technicianName(tech != null ? tech.getFullName() : null)
                .technicianPhone(tech != null ? tech.getPhone() : null)
                .slaDueAt(wo.getSlaDueAt())
                .createdAt(wo.getCreatedAt())
                .updatedAt(wo.getUpdatedAt())
                .build();
    }
}
