package com.keyStone.Playroom021.dto;

import com.keyStone.Playroom021.entity.WorkOrderStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class StatusUpdateRequest {

    @NotNull(message = "Status is required")
    private WorkOrderStatus status;

    private String note;
}
