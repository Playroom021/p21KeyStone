package com.keyStone.Playroom021.controller;

import com.keyStone.Playroom021.dto.*;
import com.keyStone.Playroom021.security.CustomUserDetails;
import com.keyStone.Playroom021.service.TechnicianService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Every endpoint here is additionally restricted to ROLE_TECHNICIAN in
 * SecurityConfig, and every call into TechnicianService is scoped to jobs
 * assigned to the caller — a technician can never see or act on another
 * technician's job, even by guessing a work-order id.
 */
@RestController
@RequestMapping("/api/technician")
@RequiredArgsConstructor
public class TechnicianController {

    private final TechnicianService technicianService;

    @GetMapping("/jobs")
    public ResponseEntity<?> myJobs(@AuthenticationPrincipal CustomUserDetails principal) {
        return ResponseEntity.ok(technicianService.listMyJobs(principal));
    }

    @GetMapping("/jobs/{id}")
    public ResponseEntity<?> getJob(@AuthenticationPrincipal CustomUserDetails principal, @PathVariable Long id) {
        return ResponseEntity.ok(technicianService.getMyJob(principal, id));
    }

    @PostMapping("/jobs/{id}/start")
    public ResponseEntity<?> start(@AuthenticationPrincipal CustomUserDetails principal, @PathVariable Long id) {
        return ResponseEntity.ok(technicianService.startJob(principal, id));
    }

    @PostMapping("/jobs/{id}/hold")
    public ResponseEntity<?> hold(@AuthenticationPrincipal CustomUserDetails principal, @PathVariable Long id,
                                   @RequestBody(required = false) Map<String, String> body) {
        String note = body == null ? null : body.get("note");
        return ResponseEntity.ok(technicianService.holdJob(principal, id, note));
    }

    @PostMapping("/jobs/{id}/resume")
    public ResponseEntity<?> resume(@AuthenticationPrincipal CustomUserDetails principal, @PathVariable Long id) {
        return ResponseEntity.ok(technicianService.startJob(principal, id));
    }

    @PostMapping("/jobs/{id}/complete")
    public ResponseEntity<?> complete(@AuthenticationPrincipal CustomUserDetails principal, @PathVariable Long id,
                                       @RequestBody(required = false) Map<String, String> body) {
        String note = body == null ? null : body.get("note");
        return ResponseEntity.ok(technicianService.completeJob(principal, id, note));
    }

    @PostMapping("/jobs/{id}/parts")
    public ResponseEntity<?> logPart(@AuthenticationPrincipal CustomUserDetails principal, @PathVariable Long id,
                                      @Valid @RequestBody PartLogRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(technicianService.logPart(principal, id, request));
    }

    @PostMapping("/jobs/{id}/time")
    public ResponseEntity<?> logTime(@AuthenticationPrincipal CustomUserDetails principal, @PathVariable Long id,
                                      @Valid @RequestBody TimeLogRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(technicianService.logTime(principal, id, request));
    }

    @PostMapping("/jobs/{id}/photos")
    public ResponseEntity<?> uploadPhoto(@AuthenticationPrincipal CustomUserDetails principal, @PathVariable Long id,
                                          @Valid @RequestBody PhotoUploadRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(technicianService.uploadPhoto(principal, id, request));
    }

    @GetMapping("/jobs/{id}/photos/{photoId}")
    public ResponseEntity<?> getPhoto(@AuthenticationPrincipal CustomUserDetails principal,
                                       @PathVariable Long id, @PathVariable Long photoId) {
        return ResponseEntity.ok(technicianService.getPhoto(principal, id, photoId));
    }
}
