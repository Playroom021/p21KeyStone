# KEYSTONE — Step 3 Handoff (Authentication + Authorization)

## 0. Important context on the starting state

The checkpoint this step started from (`KEYSTONE_CHECKPOINT_02.zip`) already
contained a **complete, working** JWT auth system from earlier steps —
signup, login, BCrypt hashing, stateless Spring Security, a `JwtAuthFilter`,
role-based `@RequestMatcher` rules, DTOs, and a `GlobalExceptionHandler` — as
well as Customer/Site/WorkOrder/Dashboard/CustomerPortal code and a
Flyway-managed PostgreSQL schema from Steps 1–2. None of that matched the
"start Step 3 from scratch" framing of this task's instructions.

Given that, this step was scoped as **review, correct, and finish Step 3**
rather than rebuild it:
- The **4 required roles didn't exist** — the codebase had `MANAGER`,
  `LOCAL_CUSTOMER`, `LOCAL_WORKER`, `DEVELOPER` instead of `MANAGER`,
  `DISPATCHER`, `TECHNICIAN`, `CUSTOMER`. This was the one real gap against
  the spec and is the main change in this step.
- No auth **tests** existed at all (only an empty `contextLoads()` smoke
  test). These were added.
- Everything already out-of-scope per this step's instructions (Customer,
  Site, WorkOrder, Dashboard, CustomerPortal, React) was **left alone**,
  except for the minimum text/string edits required to keep them compiling
  after the role rename (see table below) — no new behavior was added to
  any of them.

## 1. What changed

- **Role enum replaced**: `Role.java` now defines exactly
  `MANAGER, DISPATCHER, TECHNICIAN, CUSTOMER`, replacing
  `MANAGER, LOCAL_CUSTOMER, LOCAL_WORKER, DEVELOPER`. Mapping used
  everywhere a rename was needed: `LOCAL_CUSTOMER → CUSTOMER`,
  `LOCAL_WORKER → TECHNICIAN`, `DEVELOPER → DISPATCHER` (`MANAGER`
  unchanged). This mapping was already implied by the existing schema —
  the `work_orders.assigned_technician_id` column name predates this step.
- **New DB migration** `V2__rename_roles.sql` renames the role values on
  any existing `app_users` rows and replaces the `CHECK` constraint,
  instead of editing `V1__init_core_schema.sql` in place — per the
  project's own stated rule (Step 2 handoff, §3: "never edit
  `V1__init_core_schema.sql` once it has run anywhere").
- **`SecurityConfig`**: role-gated matchers updated to the new role names
  (`hasRole("CUSTOMER")`, `hasRole("TECHNICIAN")`, `hasRole("DISPATCHER")`).
  The `/api/dashboard/developer` matcher/endpoint was renamed to
  `/api/dashboard/dispatcher` to match; all other endpoint paths are
  unchanged.
- **Frontend static pages** (`signup.html`, `dashboard.html`,
  `customer-portal.html`, `auth.js`) had their role option values and
  role→URL maps updated to match, so they don't silently break against the
  renamed roles. No new frontend features were added (React was explicitly
  out of scope for this step and was not touched).
- **Tests added**: `AuthIntegrationTest.java` — 17 integration tests
  covering registration, login (success/failure), missing/invalid JWT,
  role-based authorization (allow + deny), and password non-exposure/
  BCrypt hashing. Full MockMvc + real Spring Security filter chain against
  the H2 in-memory test datasource (`src/test/resources/application.properties`,
  unchanged).
- **README.md**: role list and role-gated endpoint list updated to match.

### What was already correct and untouched
Registration, login, BCrypt hashing (`BCryptPasswordEncoder` via
`SecurityConfig.passwordEncoder()`), stateless JWT (`JwtUtil`,
`JwtAuthFilter`, `SessionCreationPolicy.STATELESS`), the auth DTOs
(`SignupRequest`, `LoginRequest`, `AuthResponse`, `ApiError`), the
password-never-in-response guarantee (`User.password` is never read by
`AuthResponse`/`DashboardController`/`CustomerPortalController`, only
`fullName`/`email`/`role`/`companyName`), and the `TokenBlacklistService`
logout mechanism were all already implemented correctly and needed no
changes for this step.

## 2. Files changed

| File | Change |
|---|---|
| `src/main/java/.../entity/Role.java` | Enum values replaced with the 4 required roles |
| `src/main/java/.../entity/User.java` | Comment updated (`LOCAL_CUSTOMER` → `CUSTOMER`) |
| `src/main/java/.../dto/SignupRequest.java` | Comment updated |
| `src/main/java/.../dto/AuthResponse.java` | Comment updated |
| `src/main/java/.../service/AuthService.java` | `Role.LOCAL_CUSTOMER` → `Role.CUSTOMER` (2 usages) |
| `src/main/java/.../service/CustomerPortalService.java` | Comment updated |
| `src/main/java/.../controller/CustomerPortalController.java` | Comment + `hasRole(...)` reference in Javadoc updated |
| `src/main/java/.../config/SecurityConfig.java` | Role-gated matchers updated; `/dashboard/developer` → `/dashboard/dispatcher` |
| `src/main/java/.../controller/DashboardController.java` | `developerHome()` → `dispatcherHome()`, path updated |
| `src/main/resources/db/migration/V2__rename_roles.sql` | **New** — data + constraint migration for the role rename |
| `src/main/resources/static/signup.html` | Role `<option>` values/labels updated |
| `src/main/resources/static/dashboard.html` | Role→URL map updated |
| `src/main/resources/static/customer-portal.html` | Role check string updated |
| `src/main/resources/static/js/auth.js` | Role label map + role→URL helper updated |
| `README.md` | Role list and role-gated endpoint list updated |
| `src/test/java/.../AuthIntegrationTest.java` | **New** — 17 integration tests (see §5) |
| `HANDOFF.md` | This file |

No entities, repositories, or DTOs for Customer/Site/WorkOrder were
touched. No work-order lifecycle, Parts, TimeLog, SLA, or React work was
done, per this step's explicit scope.

## 3. Auth endpoints

All under `/api/auth`, all public (`permitAll()` in `SecurityConfig`):

| Method | Path | Body | Response |
|---|---|---|---|
| POST | `/api/auth/signup` | `{fullName, email, password, role, companyName?}` | `201` + `AuthResponse` (`token, fullName, email, role, companyName`), or `409` + `ApiError` on duplicate email / missing company name for `CUSTOMER` |
| POST | `/api/auth/login` | `{email, password}` | `200` + `AuthResponse`, or `401` + `ApiError` on bad credentials |
| POST | `/api/auth/logout` | — (send `Authorization: Bearer <token>`) | `200`; blacklists the token server-side for its remaining lifetime |

`companyName` is required only when `role` is `CUSTOMER` (it becomes a new
`Customer` record the user is linked to). Every other endpoint in the app
requires `Authorization: Bearer <token>` and returns `401` if missing/
invalid/expired, via `JwtAuthEntryPoint`.

## 4. Roles

```
MANAGER
DISPATCHER
TECHNICIAN
CUSTOMER
```

Role-gated endpoints (`SecurityConfig`):

| Path | Required role |
|---|---|
| `/api/customer/**` (sites, work-orders — customer portal) | `CUSTOMER` |
| `/api/dashboard/manager` | `MANAGER` |
| `/api/dashboard/customer` | `CUSTOMER` |
| `/api/dashboard/worker` | `TECHNICIAN` |
| `/api/dashboard/dispatcher` | `DISPATCHER` |
| `/api/me`, everything else under `/api/**` | any authenticated user |

Authorities are granted as `ROLE_<name>` (Spring Security convention) from
`CustomUserDetails.getAuthorities()`, so `hasRole("CUSTOMER")` etc. match
correctly.

## 5. How to run

```bash
# 1. Config
cp .env.example .env
export $(grep -v '^#' .env | xargs)

# 2. Create the database once
psql -U postgres -c "CREATE DATABASE authapp_db;"

# 3. Build
mvn clean package

# 4. Test
mvn test

# 5. Run — Flyway applies V1 then V2 automatically on startup
mvn spring-boot:run
# or
java -jar target/authapp-1.0.0.jar
```

Try it:
```bash
curl -X POST localhost:8080/api/auth/signup -H 'Content-Type: application/json' \
  -d '{"fullName":"Asha Rao","email":"asha@example.com","password":"secret123","role":"MANAGER"}'

curl -X POST localhost:8080/api/auth/login -H 'Content-Type: application/json' \
  -d '{"email":"asha@example.com","password":"secret123"}'

curl localhost:8080/api/dashboard/manager -H 'Authorization: Bearer <token-from-above>'
```

## 6. Test results

**⚠️ Disclosed plainly, as in the Step 1 and Step 2 handoffs:** this
sandbox still has no Maven installed and no outbound network access
(`apt-get install maven` fails with `403 Forbidden` on every package —
proxy/environment restriction, not a code issue; confirmed again this
step). So `mvn clean package`, `mvn test`, and `mvn spring-boot:run` could
**not** be executed here, and the "Maven test/build" item in the test
checklist is **not independently verified end-to-end**.

What was written and manually verified instead:

- **17 tests added** in `AuthIntegrationTest.java`, covering every item on
  the requested test list:
  - Registration: valid signup (`201`, token present, password absent),
    duplicate email (`409`), missing `companyName` for `CUSTOMER` (`409`),
    all 4 roles accepted.
  - Successful login (`200`, token present, password absent).
  - Wrong password (`401`) and unknown email (`401`).
  - Missing JWT on a protected endpoint (`401`).
  - Invalid JWT — malformed token and random-garbage bearer token — on a
    protected endpoint (`401` both).
  - Role-protected endpoint: `MANAGER` token → `200` on
    `/api/dashboard/manager`; `CUSTOMER` token → `403` on the same
    endpoint; `TECHNICIAN` token → `403` on `/api/customer/sites`;
    `CUSTOMER` token → `200` on `/api/customer/sites`.
  - Password never appears in a response body, and is confirmed persisted
    as a BCrypt hash (`^\$2[aby]\$\d{2}\$.+`), not plaintext.
- Each test uses a randomly generated email so the suite has no ordering
  dependency and needs no manual DB cleanup between tests.
- All edited/created Java files were checked for balanced braces/parens
  and for every reference to the old role names (`LOCAL_CUSTOMER`,
  `LOCAL_WORKER`, `DEVELOPER`) — none remain anywhere in `.java`, `.html`,
  `.js`, or `README.md`; the only remaining occurrences are the
  intentionally-preserved historical `V1__init_core_schema.sql` and the
  explanatory comments in the new `V2__rename_roles.sql`.
- `pom.xml` was not touched this step; it already has
  `spring-boot-starter-security`, `spring-boot-starter-validation`, BCrypt
  (via Spring Security), `jjwt` 0.12.6, and `spring-security-test` (needed
  for the new tests) on the test classpath from earlier steps.

**The next developer must run `mvn clean package` and `mvn test`
immediately after unpacking this checkpoint** (no real Postgres needed for
`mvn test` — it uses the H2 test profile) and confirm all 17 new tests
plus the existing `contextLoads()` test pass, before building on top of
this step. This is now the third checkpoint in a row shipped without a
real Maven run in this sandbox — please report back either way.

## 7. Known issues

- **Build/tests unverified end-to-end** (see §6) — same unresolved
  environment limitation as Steps 1 and 2. Top priority for the next
  developer.
- `V2__rename_roles.sql` assumes the Postgres-generated default constraint
  name `app_users_role_check` (from the unnamed inline `CHECK` in V1).
  This is correct per Postgres's `<table>_<column>_check` naming
  convention, but if V1 was ever applied to a database where that
  constraint was later manually renamed, `V2` would fail with a "does not
  exist" error and need adjusting to the environment's actual name.
- The 4-role set (`MANAGER, DISPATCHER, TECHNICIAN, CUSTOMER`) is
  hard-coded in three places that must stay in sync: `Role.java`,
  `V1`+`V2`'s `CHECK` constraint list, and `signup.html`'s `<select>`. This
  was already the pattern before this step; no new abstraction was
  introduced to unify them, since that would be a larger refactor than
  this step's scope.
- `TokenBlacklistService` is in-memory only (documented in its own
  Javadoc) — fine for this checkpoint/sandbox, but would need a shared
  store (e.g. Redis) before any multi-instance deployment. Unchanged this
  step.
- As before, `app.jwt.secret` still has a placeholder default in
  `application.properties` — must be overridden via `JWT_SECRET` outside
  local dev.

## 8. What the next step should do

1. **First**, run `mvn clean package` and `mvn test` and confirm all tests
   (existing + the 17 new ones) pass; fix anything that doesn't match
   before building further.
2. Pick up the next feature slice per the project plan — work-order
   lifecycle, Parts, TimeLog, SLA, dashboard, or React frontend — as its
   own step, each schema change as its own `V3__...` migration.
3. If role-based UI/route gating grows more complex, consider centralizing
   the role list (e.g. a shared constant or generating the SQL `CHECK`
   from the Java enum at build time) instead of the three hand-synced
   locations noted in §7.
