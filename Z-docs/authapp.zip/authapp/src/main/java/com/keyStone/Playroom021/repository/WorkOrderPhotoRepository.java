package com.keyStone.Playroom021.repository;

import com.keyStone.Playroom021.entity.WorkOrderPhoto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WorkOrderPhotoRepository extends JpaRepository<WorkOrderPhoto, Long> {
    // Metadata only (no dataBase64) for list views, kept lightweight for the board/history.
    List<WorkOrderPhoto> findByWorkOrderIdOrderByUploadedAtAsc(Long workOrderId);
}
