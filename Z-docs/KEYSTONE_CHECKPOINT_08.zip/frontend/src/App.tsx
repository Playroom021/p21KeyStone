import { Route, Routes } from 'react-router-dom';
import AppLayout from './components/AppLayout';
import ProtectedRoute from './components/ProtectedRoute';
import RoleRoute from './components/RoleRoute';
import CustomerDashboardPage from './pages/CustomerDashboardPage';
import DispatcherDashboardPage from './pages/DispatcherDashboardPage';
import LoginPage from './pages/LoginPage';
import ManagerDashboardPage from './pages/ManagerDashboardPage';
import NotFoundPage from './pages/NotFoundPage';
import RootRedirect from './pages/RootRedirect';
import TechnicianDashboardPage from './pages/TechnicianDashboardPage';
import UnauthorizedPage from './pages/UnauthorizedPage';
import { ROLE_HOME } from './auth/roles';

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/" element={<RootRedirect />} />

      {/* Everything below requires a signed-in user */}
      <Route element={<ProtectedRoute />}>
        <Route path="/unauthorized" element={<UnauthorizedPage />} />

        <Route element={<AppLayout />}>
          <Route element={<RoleRoute allowed={['MANAGER']} />}>
            <Route path={ROLE_HOME.MANAGER} element={<ManagerDashboardPage />} />
          </Route>
          <Route element={<RoleRoute allowed={['DISPATCHER']} />}>
            <Route path={ROLE_HOME.DISPATCHER} element={<DispatcherDashboardPage />} />
          </Route>
          <Route element={<RoleRoute allowed={['TECHNICIAN']} />}>
            <Route path={ROLE_HOME.TECHNICIAN} element={<TechnicianDashboardPage />} />
          </Route>
          <Route element={<RoleRoute allowed={['CUSTOMER']} />}>
            <Route path={ROLE_HOME.CUSTOMER} element={<CustomerDashboardPage />} />
          </Route>
        </Route>
      </Route>

      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}
