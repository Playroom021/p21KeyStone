package com.keyStone.Playroom021.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class PhotoUploadRequest {

    @NotBlank(message = "File name is required")
    private String fileName;

    private String contentType;

    /** Raw base64 payload (no "data:image/..;base64," prefix). */
    @NotBlank(message = "Photo data is required")
    private String dataBase64;
}
