package com.keyStone.Playroom021.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;

/** Full job detail for the technician view: the work order plus its parts, time logs, photos. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TechnicianJobResponse {
    private Long id;
    private String code;
    private String title;
    private String description;
    private String customerName;
    private String siteName;
    private String siteAddress;
    private String priority;
    private String status;
    private Instant slaDueAt;
    private Instant startedAt;
    private Instant completedAt;
    private Instant createdAt;
    private int totalMinutesLogged;
    private List<StatusHistoryResponse> history;
    private List<PartResponse> parts;
    private List<TimeLogResponse> timeLogs;
    private List<PhotoResponse> photos;
}
