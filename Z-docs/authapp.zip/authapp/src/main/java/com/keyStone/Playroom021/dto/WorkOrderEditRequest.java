package com.keyStone.Playroom021.dto;

import lombok.Data;

/**
 * Partial update for a work order's title/description. Both fields are
 * optional — null means "leave unchanged" (distinct from an empty string,
 * which clears the description).
 */
@Data
public class WorkOrderEditRequest {
    private String title;
    private String description;
}
