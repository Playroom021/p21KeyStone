# KEYSTONE — Step 5 Handoff (Work Order management + lifecycle)

Starting point: `KEYSTONE_CHECKPOINT_04.zip`. Scope of this step: Work Order CRUD and
status lifecycle only. Parts, TimeLog, SLA tracking, Dashboard and React were **not**
touched.

## ⚠️ Read this first: build and tests were NOT run

Same environment limit as Steps 1–4: this sandbox has no Maven, no Maven cache and no
network (`apt-get install maven` still fails with `403 Forbidden`), so `mvn test` and
`mvn clean package` **could not be executed**. Every Java file (main + test) was checked
for balanced braces/parens and manually re-read against the classes/methods it calls, but
type/symbol resolution, JPA query derivation and actual test execution could not be
verified. **The next developer must run `mvn clean package` and `mvn test` before
building on this checkpoint**, and fix anything that fails (expected: 28 new Work Order
tests + the 45 Customer/Site tests from Step 4 + the 17 auth tests from Step 3 +
`contextLoads` = 91 total).

## 0. A pre-existing gap this step had to close

The checkpoint already had the `WorkOrder` / `WorkOrderStatusHistory` entities, their
repositories, and their DTOs from an earlier step (used only by the customer-portal
"raise a service request" flow) — but **no way for staff to look up a technician's user
id**, which is required to assign one to a work order. `AuthResponse` (signup/login) and
`GET /api/me` only ever returned `fullName`/`email`/`role`(/`companyName`), never `id`.
Fixed by adding `id` to both — a minimal, necessary enabler for task 2 ("connect Work
Orders to … Technician"), not a new feature. See §1 for the exact diff.

## 1. Changes made

- **Status rename**: `WorkOrderStatus.RESOLVED` → `COMPLETED`, to match this step's
  required status list. New migration `V3__rename_resolved_to_completed.sql` (follows
  the same pattern as Step 3's `V2__rename_roles.sql` — a new migration, not an edit to
  `V1`). Frontend (`customer-portal.html`, `style.css`) and `README.md` updated to match;
  `V1__init_core_schema.sql` itself is untouched (historical).
- **Work Order CRUD** (`WorkOrderController` → `WorkOrderService`): create, paginated
  list/search/filter, get-by-id-with-history, update (title/description/priority only),
  delete. New endpoints under `/api/work-orders`, separate from the existing
  `/api/customer/work-orders` portal endpoints (unchanged — that's still how a CUSTOMER
  raises a service request).
- **Connected to Customer, Site, Technician**: a work order's `customer` is derived from
  its `site` at creation (`site.getCustomer()`), exactly like the existing portal flow;
  `assignedTechnician` is set only via the `ASSIGNED` status transition (see below) —
  there is no separate "assign" endpoint, to keep one place responsible for "who may
  attach a technician to a work order and when."
- **Priority and status**: already modeled (`Priority`, `WorkOrderStatus` enums); nothing
  new needed there beyond the rename above.
- **Statuses**: `NEW, ASSIGNED, IN_PROGRESS, ON_HOLD, COMPLETED, CLOSED, CANCELLED` — all
  seven implemented, as required.
- **Valid status transitions enforced in the service layer** (`WorkOrderService`, not the
  controller or the DB): see §3. Both the from→to shape of the transition *and* which
  role may trigger it are checked server-side; an invalid transition is `409`, a
  disallowed role is `403`.
- **StatusHistory for every successful transition**: written inside the same
  `@Transactional` method, right after the status field is saved; a rejected transition
  (invalid shape, wrong role, or missing/invalid technician) throws before anything is
  written, so there is never a partial or inconsistent history row.
- **Role-based authorization**: path/method gates in `SecurityConfig` (who may call each
  endpoint at all) plus row-level scoping in `WorkOrderService` (whose data a given call
  actually reaches) — same two-layer pattern as Step 4's Customer/Site.
- **Technician scoping**: `CallerScope.technicianIdOrNull()` (new, alongside the existing
  `customerIdOrNull()`) returns the caller's own user id when the role is `TECHNICIAN`.
  `WorkOrderService.findAccessible()` uses it so a technician reaching for a work order
  not assigned to them gets the same `404` as a nonexistent id — never a `403` that would
  confirm the work order exists. This applies uniformly to `GET /{id}`,
  `POST /{id}/status`, and (implicitly) to the list endpoint, which is always pre-filtered
  to their own assigned work orders regardless of any `technicianId` query param they
  pass.
- **Customer isolation**: `CallerScope.customerIdOrNull()` (already existed) applied the
  same way — a `CUSTOMER` only ever lists/reads their own work orders, same `404` rule. A
  `CUSTOMER` cannot reach `POST /api/work-orders`, `PUT`, `DELETE`, or
  `POST /{id}/status` at all (`403` at the `SecurityConfig` level — they never even reach
  the service for those).
- **`id` added to `AuthResponse` and `GET /api/me`** (see §0) — the only change to
  existing Step 3/4 response shapes; purely additive, nothing existing was removed or
  renamed.
- **Shared DTOs populated more fully**: `WorkOrderResponse` / `WorkOrderDetailResponse`
  gained `customerId`, `siteId`, `assignedTechnicianId` (previously only the *name*
  strings were exposed); `StatusHistoryResponse` gained `changedByEmail` /
  `changedByRole`. These are the same DTOs the pre-existing `CustomerPortalService` uses,
  so its two builder call sites were updated to populate the new fields too — otherwise
  the old portal responses would have these fields present-but-always-null while the new
  API's responses have them populated, which would be a confusing inconsistency in a
  shared type.
- **No change** to Parts, TimeLog, SLA (not modeled — out of scope), Dashboard, or any
  React/frontend behavior beyond the two string replacements noted above.

### Files

| File | Change |
|---|---|
| `controller/WorkOrderController.java` | **New** |
| `service/WorkOrderService.java` | **New** |
| `dto/WorkOrderStatusUpdateRequest.java` | **New** |
| `security/CallerScope.java` | Added `technicianIdOrNull(...)` |
| `entity/WorkOrderStatus.java` | `RESOLVED` → `COMPLETED` |
| `db/migration/V3__rename_resolved_to_completed.sql` | **New** |
| `dto/WorkOrderRequest.java` | Added `@Size` limits (200 / 2000) matching the DB columns |
| `dto/WorkOrderResponse.java`, `WorkOrderDetailResponse.java` | Added `customerId`, `siteId`, `assignedTechnicianId` |
| `dto/StatusHistoryResponse.java` | Added `changedByEmail`, `changedByRole` |
| `dto/AuthResponse.java` | Added `id` |
| `service/AuthService.java` | Populate the new `id` field (2 builder call sites) |
| `controller/DashboardController.java` | `GET /api/me` now also returns `id` |
| `service/CustomerPortalService.java` | Populate the new response fields (§1); no behavior change |
| `repository/WorkOrderRepository.java` | Now also `JpaSpecificationExecutor`; added `findByIdAndAssignedTechnicianId`, `@EntityGraph` paged `findAll` |
| `repository/WorkOrderStatusHistoryRepository.java` | Added `deleteByWorkOrderId` (used only when deleting a `NEW` work order) |
| `config/SecurityConfig.java` | Added Step 5 matchers (8 lines) |
| `static/customer-portal.html`, `static/css/style.css`, `README.md` | `RESOLVED` → `COMPLETED` string updates |
| `test/.../WorkOrderIntegrationTest.java` | **New** — 28 tests |
| `HANDOFF.md` | This file |

No entity, repository, or DTO for Parts, TimeLog, or SLA was added. No Dashboard or React
work was done.

## 2. Work Order APIs

All require `Authorization: Bearer <jwt>` (`401` if missing/invalid).

| Method | Path | Purpose | Success |
|---|---|---|---|
| POST | `/api/work-orders` | Create `{siteId, title, description?, priority}` — customer is derived from the site | 201 |
| GET | `/api/work-orders` | List/search/filter work orders | 200 page |
| GET | `/api/work-orders/{id}` | Get one work order, with full status history | 200 |
| PUT | `/api/work-orders/{id}` | Update `{siteId, title, description?, priority}` — `siteId` in the body is ignored, the site/customer can never change | 200 |
| DELETE | `/api/work-orders/{id}` | Delete — only while status is still `NEW` | 204 |
| POST | `/api/work-orders/{id}/status` | Transition status `{status, technicianId?, note?}` — `technicianId` is required (and only used) when `status == ASSIGNED` | 200 + full detail incl. history |

**List query params**: `search` (title or code, case-insensitive contains), `status`,
`priority`, `customerId`, `siteId`, `technicianId` (staff only — see §4), `page` (0-based,
default 0), `size` (1–100, default 20), `sortBy`
(`id|code|title|priority|status|createdAt|updatedAt|slaDueAt`, default `createdAt`),
`direction` (`asc|desc`). Response: `{content[], page, size, totalElements, totalPages}`.

`WorkOrderResponse` fields: `id, code, title, customerId, customerName, siteId, siteName,
priority, status, assignedTechnicianId, assignedTechnician, slaDueAt, createdAt`.
`WorkOrderDetailResponse` adds `description, updatedAt, history[]`, where each history
entry is `{fromStatus, toStatus, note, changedByEmail, changedByRole, changedAt}`
(`fromStatus` is `null` for the creation entry).

**Status codes**: `400` validation / bad transition payload, `401` unauthenticated, `403`
role not allowed to call the endpoint or to set that particular target status, `404` not
found / not yours / not assigned to you, `409` invalid status transition or a blocked
delete.

The existing `CustomerPortalService`/`CustomerPortalController` endpoints
(`/api/customer/sites`, `/api/customer/work-orders`, `/api/customer/work-orders/{id}`)
are unchanged — a `CUSTOMER` still raises a service request there, not through
`POST /api/work-orders`.

## 3. Lifecycle rules

### Status graph (enforced in `WorkOrderService.VALID_TRANSITIONS`)

```
NEW ─────────► ASSIGNED ─────────► IN_PROGRESS ◄──► ON_HOLD
 │                 │                    │
 ▼                 ▼                    ▼
CANCELLED      CANCELLED            COMPLETED ──► CLOSED
                                         │
                                         ▼
                                     CANCELLED
```
Concretely: `NEW → {ASSIGNED, CANCELLED}`; `ASSIGNED → {IN_PROGRESS, ON_HOLD,
CANCELLED}`; `IN_PROGRESS → {ON_HOLD, COMPLETED, CANCELLED}`; `ON_HOLD → {IN_PROGRESS,
CANCELLED}`; `COMPLETED → {CLOSED}`; `CLOSED` and `CANCELLED` are terminal (no further
transitions). Any pair not in this table is rejected with `409`.

### Who may trigger which target status (checked independently of the above)

| Target status | Allowed roles |
|---|---|
| `ASSIGNED` | MANAGER, DISPATCHER (requires `technicianId` in the body; that user must exist and have role `TECHNICIAN`, else `400`/`404`) |
| `IN_PROGRESS`, `ON_HOLD`, `COMPLETED` | MANAGER, DISPATCHER, TECHNICIAN |
| `CLOSED`, `CANCELLED` | MANAGER, DISPATCHER only |

A `TECHNICIAN` can therefore start, pause/resume, and complete work on a job assigned to
them, but cannot self-assign, cancel, or formally close one — those remain dispatch/
management decisions. A disallowed role for an otherwise-valid transition is `403`; an
invalid transition shape (regardless of role) is `409` and is checked first, so e.g. a
`TECHNICIAN` trying `NEW → COMPLETED` gets `409` (bad shape), while a `TECHNICIAN` trying
the valid `ASSIGNED → CANCELLED` gets `403` (role not permitted).

### Other lifecycle/CRUD rules
- `PUT` is blocked (`409`) once a work order is `CLOSED` or `CANCELLED`.
- `DELETE` is only allowed while status is still `NEW` (`409` otherwise) — once anything
  has happened to a work order, deleting it would destroy history nobody asked to delete;
  cancel it instead. Deleting a `NEW` order also deletes its one history row (the
  creation entry) first, to satisfy the FK.
- `slaDueAt` is computed from priority at creation exactly as the existing portal flow
  does (CRITICAL +4h, HIGH +24h, MEDIUM +48h, LOW +72h) — unchanged, just reused.
- There is no "reassign technician" action distinct from the `ASSIGNED` transition. To
  change who's assigned once already `ASSIGNED`/`IN_PROGRESS`/`ON_HOLD`, the only way
  with this step's code is to go through another non-`ASSIGNED` transition and back — in
  practice this means reassignment isn't really supported yet; see §5 Known issues.

## 4. Tests (`WorkOrderIntegrationTest`, 28 tests)

MockMvc through the real security filter chain on the H2 test DB (existing test profile,
unchanged). Each test signs up its own users and tags names with a random suffix, so
there is no ordering dependency and no cleanup needed.

- **CRUD** (9): create by MANAGER / by DISPATCHER, create against an unknown site (404),
  create with a blank title (400), get-by-id includes the creation history entry,
  get unknown id (404), update changes fields but not site/customer, delete a `NEW` work
  order (204, then 404), delete by DISPATCHER (403 — MANAGER only), delete after
  assignment (409 — no longer `NEW`).
- **Valid transitions + history** (2): a full lifecycle
  `NEW→ASSIGNED→IN_PROGRESS→ON_HOLD→IN_PROGRESS→COMPLETED→CLOSED` across a MANAGER and a
  TECHNICIAN, asserting exactly 7 history rows with the right from/to/role on each; cancel
  from `NEW` by a DISPATCHER, then confirm `CANCELLED` is terminal.
- **Invalid transitions** (4): `NEW → IN_PROGRESS` directly (409), any transition out of
  `CLOSED` (409), `ASSIGNED` with no `technicianId` (400), `ASSIGNED` with a user who
  isn't a `TECHNICIAN` (400).
- **Technician authorization** (6): cannot self-assign (403), cannot cancel/close (403),
  `GET` on a work order assigned to someone else (404) vs. their own (200), status
  transition on a work order assigned to someone else (404), list only ever shows their
  own assigned work orders, cannot `PUT` (403, blocked at `SecurityConfig` regardless of
  assignment).
- **Customer isolation** (6): list only shows their own, `GET` on another customer's work
  order (404), cannot create via the staff endpoint (403, portal endpoint unaffected),
  cannot transition status (403), cannot delete (403).
- **Cross-cutting** (1): unauthenticated list request (401).

**Not verified by a real run — see the warning at the top.**

## 5. Known issues

- **Build and tests unverified** (see top). Highest priority for the next developer.
- **No technician reassignment action.** Once a work order is `ASSIGNED` to someone, this
  step has no endpoint to hand it to a different technician without an unrelated status
  bounce. Not required by this step's task list, but likely needed soon — a natural
  Step 6 candidate would be a dedicated `PATCH .../technician` or allowing `technicianId`
  on the existing `PUT` for staff.
- **Role-permission-denied transitions return a bare `403`** with no JSON body (Spring
  Security's default `AccessDeniedHandler`, same as the Step 4 `DELETE` endpoints) rather
  than a `ConflictException`/`ApiError`-style body. Consistent with the existing codebase
  pattern, but worth deciding on a custom `AccessDeniedHandler` if a uniform error body
  across all 403s is wanted later.
- **`V3__rename_resolved_to_completed.sql` assumes Postgres's default constraint names**
  (`work_orders_status_check`, `work_order_status_history_from_status_check`,
  `work_order_status_history_to_status_check`) — correct per Postgres's
  `<table>_<column>_check` convention for the unnamed inline `CHECK`s in `V1`, but would
  need adjusting if those were ever renamed by hand. Same caveat already noted for `V2`'s
  `app_users_role_check` in the Step 3 handoff.
- **Old and new work-order endpoints coexist**, same as Step 4's Site endpoints:
  `/api/customer/work-orders` (portal, `WorkOrderResponse`/`WorkOrderDetailResponse`, read
  + create-only) and `/api/work-orders` (this step, full CRUD + lifecycle). Not merged,
  per "no unrelated changes" — a future step could fold the portal's read endpoints into
  the new one now that the new one already supports `CUSTOMER` scoping.
- **`README.md` was not updated with the Work Order API reference** (only the
  `RESOLVED`→`COMPLETED` status-flow line was fixed) — same gap already noted as a known
  issue in the Step 4 handoff for the Customer/Site APIs; still unaddressed.
- Carried over from Steps 3–4: in-memory `TokenBlacklistService`, placeholder default
  `app.jwt.secret` (override `JWT_SECRET`), `V2__rename_roles.sql`'s own constraint-name
  assumption, and customers/site names are not unique.

## 6. Next step

1. Run `mvn clean package` and `mvn test`; fix any compile/test failures from Steps 3–5
   (91 tests expected to pass: 17 + 45 + 28 + `contextLoads`).
2. Only then start the next slice — Parts, TimeLog, SLA, dashboard, or React — each
   schema change as its own `V4__...` migration.
3. Decide on technician reassignment (§5) and whether to fold the portal's work-order
   endpoints into the new `/api/work-orders` API.

## 7. How to run

```bash
cp .env.example .env && export $(grep -v '^#' .env | xargs)
psql -U postgres -c "CREATE DATABASE authapp_db;"
mvn clean package     # runs tests (H2, no Postgres needed)
mvn spring-boot:run   # Flyway applies V1, V2, V3 on startup
```

Try it (after signing up a MANAGER, a CUSTOMER with a site, and a TECHNICIAN):
```bash
curl -X POST localhost:8080/api/work-orders -H 'Authorization: Bearer <manager-token>' \
  -H 'Content-Type: application/json' \
  -d '{"siteId":1,"title":"AC not cooling","priority":"HIGH"}'

curl -X POST localhost:8080/api/work-orders/1/status -H 'Authorization: Bearer <manager-token>' \
  -H 'Content-Type: application/json' \
  -d '{"status":"ASSIGNED","technicianId":<technician-id-from-signup-response>}'

curl -X POST localhost:8080/api/work-orders/1/status -H 'Authorization: Bearer <technician-token>' \
  -H 'Content-Type: application/json' \
  -d '{"status":"IN_PROGRESS"}'
```
