package com.keyStone.Playroom021.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/** Work order row for the dispatcher board — includes ids needed for reassignment. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BoardWorkOrderResponse {
    private Long id;
    private String code;
    private String title;
    private String description;
    private Long customerId;
    private String customerName;
    private Long siteId;
    private String siteName;
    private String priority;
    private String status;
    private Long technicianId;
    private String technicianName;
    private String technicianPhone;
    private Instant slaDueAt;
    private Instant createdAt;
    private Instant updatedAt;
}
