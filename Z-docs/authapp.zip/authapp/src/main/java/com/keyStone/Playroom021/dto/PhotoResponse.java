package com.keyStone.Playroom021.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/** Metadata only — no dataBase64 — for list views. Fetch by id for the full image. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PhotoResponse {
    private Long id;
    private String fileName;
    private String contentType;
    private String uploadedByEmail;
    private Instant uploadedAt;
}
