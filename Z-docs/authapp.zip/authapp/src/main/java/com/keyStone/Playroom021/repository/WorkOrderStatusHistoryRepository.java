package com.keyStone.Playroom021.repository;

import com.keyStone.Playroom021.entity.WorkOrderStatusHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface WorkOrderStatusHistoryRepository extends JpaRepository<WorkOrderStatusHistory, Long> {

    List<WorkOrderStatusHistory> findByWorkOrderIdOrderByChangedAtAsc(Long workOrderId);

    @Modifying
    @Query("delete from WorkOrderStatusHistory h where h.workOrder.id = :workOrderId")
    void purgeByWorkOrderId(@Param("workOrderId") Long workOrderId);
}
