package com.keyStone.Playroom021.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CustomerRequest {

    @NotBlank(message = "Company name is required")
    private String companyName;

    @Email(message = "Contact email must be valid")
    private String contactEmail;
}
