package com.keyStone.Playroom021.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class DispatcherSiteRequest {

    @NotNull(message = "Customer is required")
    private Long customerId;

    @NotBlank(message = "Site name is required")
    private String name;

    private String addressLine;

    private String city;
}
