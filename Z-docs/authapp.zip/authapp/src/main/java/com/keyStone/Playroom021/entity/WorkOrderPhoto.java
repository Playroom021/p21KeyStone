package com.keyStone.Playroom021.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/**
 * A photo a technician attached to a work order. Stored inline as base64 for
 * simplicity (no object storage wired up yet) — fine for a handful of phone
 * photos per job; swap for S3/Blob storage + a URL column if volume grows.
 */
@Entity
@Table(name = "work_order_photos")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkOrderPhoto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "work_order_id", nullable = false)
    private WorkOrder workOrder;

    @Column(length = 150)
    private String fileName;

    @Column(length = 100)
    private String contentType;

    @Lob
    @Column(nullable = false)
    private String dataBase64;

    @Column(length = 150)
    private String uploadedByEmail;

    @Column(nullable = false, updatable = false)
    private Instant uploadedAt;

    @PrePersist
    protected void onCreate() {
        this.uploadedAt = Instant.now();
    }
}
