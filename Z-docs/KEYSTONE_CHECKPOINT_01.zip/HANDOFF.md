# KEYSTONE — Step 1 Handoff (Backend Foundation)

## 1. What was completed

This phase prepared the existing `authapp` Spring Boot project as the
KEYSTONE backend foundation. No business features, JWT changes, or
frontend work were added — per scope, this was infrastructure/config only.

Specifically:
- Bumped the project from Java 17 to **Java 21** (`pom.xml`).
- Confirmed the layered architecture (Controller → Service → Repository →
  Entity) already present in the inherited `authapp` codebase was intact
  and did not need restructuring.
- Moved `GlobalExceptionHandler` out of the `config` package into its own
  dedicated `exception` package, matching the required package layout.
  Behavior is unchanged (`@RestControllerAdvice` is found by component
  scan regardless of package, so this is a pure organizational move).
- Converted `application.properties` from hardcoded local values to
  **environment-variable-driven configuration** with safe local-dev
  fallbacks (`${VAR:default}` syntax), covering server port, datasource
  URL/username/password, JPA settings, and the existing JWT secret/expiry.
- Added `.env.example` documenting every environment variable the app
  reads, with placeholder (non-real) values.
- Added `.env` to `.gitignore` so real local secrets are never committed.
- Added a minimal test setup that did not exist before: an H2 in-memory
  test datasource (`src/test/resources/application.properties`) and a
  single Spring context-load smoke test
  (`AuthAppApplicationTests.contextLoads()`), so `mvn test` has something
  real to run without requiring a live PostgreSQL instance. No business
  logic assertions were added — that's explicitly out of scope for Step 1.
- Updated `README.md`: package layout list, JDK 21 prerequisite, a new
  "Configure (environment variables)" section with a variable reference
  table, and JDK version references in the deployment section (including
  the example Dockerfile base image).

### MySQL check
The inherited project was **already PostgreSQL-only** — there was no
MySQL driver, URL, or dialect anywhere in the codebase (`pom.xml`,
`application.properties`, or Java source). Nothing needed to be removed
or replaced on that front; this is noted here so the next developer
knows it was checked, not skipped.

### JWT / business features
Existing JWT authentication (`JwtUtil`, `JwtAuthFilter`,
`TokenBlacklistService`, etc.), the customer portal, and work-order
domain code were **left as-is** and preserved. Per the Step 1 instructions,
no new JWT logic and no new business features were implemented — the only
change touching JWT config was moving the secret/expiry to environment
variables.

## 2. Files changed

| File | Change |
|---|---|
| `pom.xml` | `java.version` 17 → 21; added `h2` test-scope dependency |
| `src/main/resources/application.properties` | Rewritten to be environment-variable driven |
| `src/main/java/.../config/GlobalExceptionHandler.java` | **Removed** (moved) |
| `src/main/java/.../exception/GlobalExceptionHandler.java` | **New** — same content, new package |
| `.env.example` | **New** |
| `.gitignore` | Added `.env` |
| `README.md` | Updated: Java 21, project layout, new env-var config section, Docker base image |
| `src/test/resources/application.properties` | **New** — H2 test config |
| `src/test/java/.../AuthAppApplicationTests.java` | **New** — context-load smoke test |

No other source files (controllers, services, repositories, entities,
DTOs, security classes, static frontend files) were modified.

## 3. Current Java version
**Java 21** (`pom.xml` `<java.version>`).

## 4. Current Spring Boot version
**Spring Boot 3.3.4** (unchanged from the inherited project; already a
3.x release, satisfies the spec).

## 5. Database configuration status
- **PostgreSQL**, already the only database in this project (no MySQL
  ever present — see note above).
- Fully environment-variable driven: `DB_URL`, `DB_USERNAME`,
  `DB_PASSWORD`, with local-dev defaults pointing at
  `jdbc:postgresql://localhost:5432/authapp_db`.
- `spring.jpa.hibernate.ddl-auto` defaults to `update` (creates tables on
  boot); overridable via `JPA_DDL_AUTO`.
- Test-time context uses an in-memory H2 database instead (see above) —
  this does **not** affect runtime/production config.

## 6. Commands used to run the project

```bash
# 1. Provide config (either export real env vars, or rely on local defaults
#    if you have PostgreSQL running locally on the default port/db/user):
cp .env.example .env
export $(grep -v '^#' .env | xargs)

# 2. Build
mvn clean package

# 3. Test
mvn test

# 4. Run
mvn spring-boot:run
# or
java -jar target/authapp-1.0.0.jar
```

## 7. Tests performed

**⚠️ Important — disclose plainly:** Maven is not installed and outbound
network access is disabled in the sandbox this work was done in, so
`mvn test`, `mvn clean package`, and `mvn spring-boot:run` could **not**
actually be executed here. This is a limitation of the working
environment, not a statement about the code's correctness.

What *was* done instead, as the closest available verification:
- Verified `pom.xml` is well-formed XML.
- Verified every Java file's `package` declaration matches its directory
  path (no misplaced files after the `exception` package move).
- Verified no dangling references to the old
  `config.GlobalExceptionHandler` location (Spring finds
  `@RestControllerAdvice` beans via component scan, not by import, so
  the move is safe either way).
- Verified — by grep across all `.xml`, `.properties`, and `.java` files —
  that no MySQL driver, URL, or dialect exists anywhere in the project.
- Manually reviewed `JwtUtil` and `SecurityConfig` to confirm the
  environment-variable property changes don't alter any bean wiring or
  startup behavior.

**The next developer must run `mvn clean package` and `mvn test`
themselves** on a machine with Maven and network access, immediately
after unpacking this checkpoint, before building on top of it. Treat that
as the first verification step of the next session, not an optional
extra.

## 8. Known issues / risks

- **Build/tests unverified end-to-end** (see above) — this is the single
  most important caveat for the next developer to resolve first.
- No H2/test infrastructure existed before this phase; the new
  `AuthAppApplicationTests.contextLoads()` test is intentionally minimal
  (no business-logic assertions) and should be expanded once actual
  feature work resumes.
- The original project report (KEYSTONE_Project_Report.pdf) describes a
  *different*, MySQL/Railway-deployed variant of this project with a
  `user_auth` table and `/api/user_auth/**` endpoints. The codebase
  actually supplied here (`authapp.zip`) is PostgreSQL-based with
  `/api/auth/**` endpoints and a different package (`com.keyStone.Playroom021`).
  These are not the same build. The next developer should confirm which
  lineage is authoritative going forward — this handoff assumes the
  supplied `authapp.zip` codebase is the one to continue from.
- `app.jwt.secret` still has a placeholder default value in
  `application.properties` for local-dev convenience. This must be
  overridden via `JWT_SECRET` in every non-local environment.

## 9. Exact instructions for the next developer

1. Unzip this checkpoint.
2. Install JDK 21 and Maven 3.9+ if not already available.
3. Have a local PostgreSQL instance running, or export `DB_URL` /
   `DB_USERNAME` / `DB_PASSWORD` pointing at one you have.
4. Run `mvn clean package` then `mvn test` — confirm both succeed before
   changing anything. Report/fix any failures found; none are expected
   from this phase's changes, but they have not been machine-verified.
5. Run `mvn spring-boot:run` and confirm the app starts on
   `http://localhost:8080` and existing endpoints (`/api/auth/signup`,
   `/api/auth/login`, `/api/customer/**`) still respond as documented in
   `README.md`.
6. Do **not** start Step 2 (authentication redesign, work orders, SLA,
   parts, dashboard, or the React frontend) until the above is confirmed
   working.
