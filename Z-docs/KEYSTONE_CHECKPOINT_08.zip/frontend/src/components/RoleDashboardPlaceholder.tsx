import { useEffect, useState } from 'react';
import { fetchDashboardGreeting } from '../api/dashboard';
import { getErrorMessage } from '../api/client';
import { useAuth } from '../auth/AuthContext';
import { ROLE_LABEL } from '../auth/roles';

/**
 * Placeholder body shared by the four role pages. It makes one real
 * authenticated call (the role's existing dashboard stub endpoint) to prove
 * the JWT is sent and accepted. Real dashboards are a later step.
 */
export default function RoleDashboardPlaceholder({ description }: { description: string }) {
  const { user } = useAuth();
  const [greeting, setGreeting] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    fetchDashboardGreeting(user.role)
      .then((msg) => !cancelled && setGreeting(msg))
      .catch((e) => !cancelled && setError(getErrorMessage(e, 'Could not load dashboard')));
    return () => {
      cancelled = true;
    };
  }, [user]);

  if (!user) return null;

  return (
    <section className="card">
      <h1>{ROLE_LABEL[user.role]} dashboard</h1>
      <p className="muted">{description}</p>
      <p>
        <strong>Backend connection:</strong>{' '}
        {error ? (
          <span className="error-text">{error}</span>
        ) : greeting ? (
          <span className="ok-text">{greeting}</span>
        ) : (
          <span className="muted">checking…</span>
        )}
      </p>
      <p className="muted">Placeholder page. Full dashboard coming in a later step.</p>
    </section>
  );
}
