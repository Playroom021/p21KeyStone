import { useState } from 'react';
import { Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { ROLE_LABEL } from '../auth/roles';

/** Header + page area shared by every signed-in page. */
export default function AppLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);

  async function handleLogout() {
    setBusy(true);
    await logout();
    navigate('/login', { replace: true });
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <strong className="brand">KEYSTONE</strong>
        {user && (
          <div className="user-box">
            <span>
              {user.fullName} <span className="badge">{ROLE_LABEL[user.role]}</span>
            </span>
            <button type="button" className="btn btn-secondary" onClick={handleLogout} disabled={busy}>
              {busy ? 'Signing out…' : 'Log out'}
            </button>
          </div>
        )}
      </header>
      <main className="app-main">
        <Outlet />
      </main>
    </div>
  );
}
