package com.keyStone.Playroom021.repository;

import com.keyStone.Playroom021.entity.WorkOrderTimeLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WorkOrderTimeLogRepository extends JpaRepository<WorkOrderTimeLog, Long> {
    List<WorkOrderTimeLog> findByWorkOrderIdOrderByLoggedAtAsc(Long workOrderId);

    @org.springframework.data.jpa.repository.Query(
        "select coalesce(sum(t.minutes), 0) from WorkOrderTimeLog t where t.workOrder.id = :workOrderId")
    int sumMinutesByWorkOrderId(@org.springframework.data.repository.query.Param("workOrderId") Long workOrderId);
}
