import { api } from './client';
import type { Role } from '../types/auth';

/** Existing role-specific stub endpoints (Step 3). Real dashboards come later. */
const DASHBOARD_PATH: Record<Role, string> = {
  MANAGER: '/api/dashboard/manager',
  DISPATCHER: '/api/dashboard/dispatcher',
  TECHNICIAN: '/api/dashboard/worker',
  CUSTOMER: '/api/dashboard/customer',
};

export async function fetchDashboardGreeting(role: Role): Promise<string> {
  const { data } = await api.get<{ message: string }>(DASHBOARD_PATH[role]);
  return data.message;
}
