# KEYSTONE — Step 4 Handoff (Customer + Site management)

Starting point: `KEYSTONE_CHECKPOINT_03.zip`. Scope of this step: Customer CRUD and
Site CRUD only. Work Order, Parts, TimeLog, SLA, Dashboard and React were **not** touched
(the pre-existing work-order/dashboard/customer-portal code is unchanged).

## ⚠️ Read this first: build and tests were NOT run

Same environment limit as Steps 1–3: this sandbox has no Maven, no Maven cache and no
network, so `mvn test` and `mvn clean package` **could not be executed**. What was done
instead: every Java file (main + test) was run through `javac` in parse mode, and there
are **no syntax errors**. Type/symbol resolution could not be checked (no dependency
jars), so compile errors, JPA/Specification issues and test failures are all still
possible. **The next developer must run `mvn clean package` and `mvn test` before
building on this checkpoint**, and fix anything that fails (expected: 45 new tests +
the 17 auth tests from Step 3 + `contextLoads`).

## 1. Changes made

- **Customer CRUD**: `CustomerController` → `CustomerService` → `CustomerRepository`,
  with `CustomerRequest` / `CustomerResponse` DTOs and Bean Validation.
- **Site CRUD**: `SiteController` → `SiteService` → `SiteRepository`, with the existing
  `SiteRequest` (size limits added) and a new `SiteDetailResponse`.
- **Relationship**: a Customer has many Sites; a Site belongs to exactly one Customer.
  The customer is fixed at creation (taken from the URL path) and **cannot be changed by
  an update** — a `customerId` in a PUT body is ignored.
- **Pagination / search / sort** on both list endpoints (see §3). Sort fields are
  whitelisted; `size` is capped at 100; `%` and `_` in a search term are treated literally.
- **Authorization**: role gates in `SecurityConfig` (method + path matchers) plus
  row-level scoping in the services via `security/CallerScope`. A `CUSTOMER`'s customer
  id always comes from the authenticated principal, never from request input. Asking for
  another customer's data returns the **same 404** as a nonexistent id (existence is not
  revealed).
- **Delete safety** (no cascading): deleting a Customer is refused with `409` while it
  still has sites, work orders, or linked user accounts; deleting a Site is refused with
  `409` while work orders reference it.
- **Errors**: `GlobalExceptionHandler` gained 404 (`EntityNotFoundException`),
  409 (`ConflictException`) and 400 (`InvalidRequestException`) handlers. The existing
  validation handler is unchanged. All use the existing `ApiError {status, message}` body.
- **No DB migration.** The existing `customers` / `sites` tables already fit; no `V3`.

### Files
| File | Change |
|---|---|
| `controller/CustomerController.java` | **New** |
| `controller/SiteController.java` | **New** |
| `service/CustomerService.java` | **New** |
| `service/SiteService.java` | **New** |
| `service/PagingSupport.java` | **New** — page/sort validation, LIKE-pattern escaping |
| `security/CallerScope.java` | **New** — "which customer may this caller see?" |
| `dto/CustomerRequest.java`, `CustomerResponse.java`, `SiteDetailResponse.java`, `PageResponse.java` | **New** |
| `exception/ConflictException.java`, `InvalidRequestException.java` | **New** |
| `exception/GlobalExceptionHandler.java` | Added 3 handlers |
| `config/SecurityConfig.java` | Added Step 4 matchers (11 lines) |
| `dto/SiteRequest.java` | Added `@Size` limits (150 / 255 / 100) matching the DB columns |
| `repository/CustomerRepository.java` | Now also `JpaSpecificationExecutor` |
| `repository/SiteRepository.java` | `JpaSpecificationExecutor`, `existsByCustomerId`, paged `findAll` with `@EntityGraph(customer)` |
| `repository/UserRepository.java` | `existsByCustomerId` |
| `repository/WorkOrderRepository.java` | `existsByCustomerId`, `existsBySiteId` |
| `test/.../CustomerSiteIntegrationTest.java` | **New** — 45 tests |
| `HANDOFF.md` | This file |

## 2. APIs added

All require `Authorization: Bearer <jwt>` (`401` if missing/invalid).

| Method | Path | Purpose | Success |
|---|---|---|---|
| POST | `/api/customers` | Create customer `{companyName, contactEmail?}` | 201 |
| GET | `/api/customers` | List/search customers | 200 page |
| GET | `/api/customers/me` | The calling CUSTOMER's own record | 200 |
| GET | `/api/customers/{id}` | Get one customer | 200 |
| PUT | `/api/customers/{id}` | Update customer | 200 |
| DELETE | `/api/customers/{id}` | Delete customer (blocked if it has dependants) | 204 |
| POST | `/api/customers/{customerId}/sites` | Create site `{name, addressLine?, city?}` | 201 |
| GET | `/api/customers/{customerId}/sites` | List/search one customer's sites | 200 page |
| GET | `/api/sites` | List/search sites; optional `customerId` filter | 200 page |
| GET | `/api/sites/{id}` | Get one site | 200 |
| PUT | `/api/sites/{id}` | Update site (customer cannot change) | 200 |
| DELETE | `/api/sites/{id}` | Delete site (blocked if it has work orders) | 204 |

**List query params** (both list types): `search` (case-insensitive contains; customers →
company name or contact email; sites → name, address or city), `page` (0-based, default 0),
`size` (1–100, default 20), `sortBy` (customers: `id|companyName|createdAt`, default
`companyName`; sites: `id|name|city|createdAt`, default `name`), `direction` (`asc|desc`).
Response: `{content[], page, size, totalElements, totalPages}`.

**Status codes**: `400` validation / bad paging params, `401` unauthenticated, `403` role
not allowed, `404` not found *or not yours*, `409` blocked delete.

### Role matrix
| Action | MANAGER | DISPATCHER | TECHNICIAN | CUSTOMER |
|---|---|---|---|---|
| Create / update customer | ✅ | ✅ | ❌ 403 | ❌ 403 |
| Delete customer | ✅ | ❌ 403 | ❌ 403 | ❌ 403 |
| List all customers | ✅ | ✅ | ✅ | ❌ 403 |
| Get customer by id | ✅ | ✅ | ✅ | own only (else 404) |
| `GET /customers/me` | ❌ 403 | ❌ 403 | ❌ 403 | ✅ |
| Create / update site | ✅ | ✅ | ❌ 403 | own customer only (else 404) |
| Delete site | ✅ | ❌ 403 | ❌ 403 | ❌ 403 |
| List / get sites | ✅ all | ✅ all | ✅ all | own only |

These were my own choices where the task didn't specify (e.g. technicians read-only,
delete = MANAGER only, customers may manage their own sites). They live in one block in
`SecurityConfig` and are easy to change.

## 3. Tests (`CustomerSiteIntegrationTest`, 45 tests)

MockMvc through the real security filter chain on the H2 test DB (existing test profile,
unchanged). Each test signs up its own users and uses a random tag in names, so there is
no ordering dependency and no cleanup.

- **Customer CRUD** (7): create, name trimming, read, update, delete→404, unknown id 404 (get/put/delete).
- **Customer validation** (5): blank / missing / >150-char company name, invalid email, blank on update.
- **Pagination / search / sort** (5): paging + case-insensitive search, search by contact email, descending sort, `%` treated literally, invalid `page`/`size`/`sortBy`/`direction` → 400.
- **Site CRUD** (6): create (with customer link), read, update (customer unchanged even if body sends another `customerId`), delete, unknown id 404, create under unknown customer 404.
- **Site validation** (3): blank name, over-length name/address/city, blank on update.
- **Relationship** (7): one customer with several sites, each site tied to one customer; `/api/sites` filtered by customer and by name/city; paging + sort on sites; unknown customer filter 404; delete customer blocked by sites (then allowed once removed); blocked by linked portal account; site delete blocked by work order.
- **Authorization — staff** (5): unauthenticated 401, invalid JWT 401, DISPATCHER (create/update ok, delete 403), TECHNICIAN read-only, MANAGER full access.
- **Authorization — CUSTOMER** (7): `/me`, `/me` forbidden for staff, own customer readable / others 404, cannot list/create/update/delete customers, manages own sites (delete 403), cannot read/list/create/update another customer's sites (404), site listing always scoped to own customer.

**Not verified by a real run — see the warning at the top.**

## 4. Known issues / notes

- **Build and tests unverified** (see top). Highest priority for the next developer.
- **Old and new site endpoints coexist.** The Step 2 customer-portal endpoints
  (`/api/customer/sites`, `/api/customer/work-orders`, …) are unchanged and still use
  `SiteResponse`; the new `/api/sites` API uses `SiteDetailResponse`. I did not merge
  them because that would be an unrelated change. They could be consolidated later.
- `SiteRequest` (shared with the old portal endpoint) now enforces max lengths, so the
  portal endpoint returns 400 instead of a DB error for over-long values.
- **Company names are not unique** (signup already allowed duplicates); there is no
  duplicate-name check on customers or on site names within a customer.
- **Test profile differs from prod**: `src/test/resources/application.properties` shadows
  the main file, so `spring.jpa.open-in-view=false` is not applied in tests. The new
  services are `@Transactional`, so they don't depend on it, but lazy-loading mistakes
  elsewhere could be hidden by tests.
- Customers cannot edit their own customer profile (`PUT /api/customers/{id}` is
  MANAGER/DISPATCHER only).
- Carried over from Step 3: in-memory `TokenBlacklistService`, placeholder default
  `app.jwt.secret` (override `JWT_SECRET`), and `V2__rename_roles.sql` assumes the
  default constraint name `app_users_role_check`.
- README.md was not updated with the new endpoints.

## 5. Next step

1. Run `mvn clean package` and `mvn test`; fix any compile/test failures from Steps 3–4.
2. Only then start the next slice (work-order lifecycle, Parts, TimeLog, SLA, dashboard,
   or React), each schema change as its own `V3__...` migration.
3. Decide whether to fold the old `/api/customer/**` portal site endpoints into the new
   Site API.

## 6. How to run

```bash
cp .env.example .env && export $(grep -v '^#' .env | xargs)
psql -U postgres -c "CREATE DATABASE authapp_db;"
mvn clean package     # runs tests (H2, no Postgres needed)
mvn spring-boot:run   # Flyway applies V1, V2 on startup
```
