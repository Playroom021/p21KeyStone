package com.keyStone.Playroom021.controller;

import com.keyStone.Playroom021.dto.*;
import com.keyStone.Playroom021.security.CustomUserDetails;
import com.keyStone.Playroom021.service.DispatcherService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/** Every endpoint here is additionally restricted to ROLE_DISPATCHER in SecurityConfig. */
@RestController
@RequestMapping("/api/dispatcher")
@RequiredArgsConstructor
public class DispatcherController {

    private final DispatcherService dispatcherService;

    @PostMapping("/customers")
    public ResponseEntity<?> createCustomer(@Valid @RequestBody CustomerRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(dispatcherService.createCustomer(request));
    }

    @GetMapping("/customers")
    public ResponseEntity<?> listCustomers() {
        return ResponseEntity.ok(dispatcherService.listCustomers());
    }

    @PostMapping("/sites")
    public ResponseEntity<?> createSite(@Valid @RequestBody DispatcherSiteRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(dispatcherService.createSite(request));
    }

    @GetMapping("/sites")
    public ResponseEntity<?> listSites() {
        return ResponseEntity.ok(dispatcherService.listSites());
    }

    @GetMapping("/technicians")
    public ResponseEntity<?> listTechnicians() {
        return ResponseEntity.ok(dispatcherService.listTechnicians());
    }

    @GetMapping("/work-orders")
    public ResponseEntity<?> board() {
        return ResponseEntity.ok(dispatcherService.listBoard());
    }

    @PostMapping("/work-orders")
    public ResponseEntity<?> createWorkOrder(@AuthenticationPrincipal CustomUserDetails principal,
                                              @Valid @RequestBody WorkOrderCreateRequest request) {
        BoardWorkOrderResponse created = dispatcherService.createWorkOrder(principal.getUsername(), request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PatchMapping("/work-orders/{id}")
    public ResponseEntity<?> updateWorkOrder(@AuthenticationPrincipal CustomUserDetails principal,
                                              @PathVariable Long id,
                                              @RequestBody WorkOrderEditRequest request) {
        return ResponseEntity.ok(dispatcherService.updateWorkOrder(principal.getUsername(), id, request));
    }

    @DeleteMapping("/work-orders/{id}")
    public ResponseEntity<?> deleteWorkOrder(@PathVariable Long id) {
        dispatcherService.deleteWorkOrder(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/work-orders/{id}/assign")
    public ResponseEntity<?> assign(@AuthenticationPrincipal CustomUserDetails principal,
                                     @PathVariable Long id,
                                     @Valid @RequestBody AssignTechnicianRequest request) {
        return ResponseEntity.ok(dispatcherService.assignTechnician(principal.getUsername(), id, request.getTechnicianId()));
    }

    @PostMapping("/work-orders/{id}/reassign")
    public ResponseEntity<?> reassign(@AuthenticationPrincipal CustomUserDetails principal,
                                       @PathVariable Long id,
                                       @Valid @RequestBody AssignTechnicianRequest request) {
        return ResponseEntity.ok(dispatcherService.assignTechnician(principal.getUsername(), id, request.getTechnicianId()));
    }
}
