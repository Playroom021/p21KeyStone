package com.keyStone.Playroom021.service;

import com.keyStone.Playroom021.dto.*;
import com.keyStone.Playroom021.entity.*;
import com.keyStone.Playroom021.repository.*;
import com.keyStone.Playroom021.security.CustomUserDetails;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Base64;
import java.util.List;

/**
 * Every method here takes the acting technician's id from the authenticated
 * principal and every lookup is scoped by it (findByIdAndAssignedTechnicianId),
 * so a technician can only ever see or act on jobs assigned to them — the same
 * "scoped by construction" pattern CustomerPortalService uses for customers.
 */
@Service
@RequiredArgsConstructor
public class TechnicianService {

    private final WorkOrderRepository workOrderRepository;
    private final WorkOrderStatusHistoryRepository historyRepository;
    private final WorkOrderPartRepository partRepository;
    private final WorkOrderTimeLogRepository timeLogRepository;
    private final WorkOrderPhotoRepository photoRepository;

    public List<BoardWorkOrderResponse> listMyJobs(CustomUserDetails principal) {
        return workOrderRepository.findByAssignedTechnicianIdOrderByCreatedAtDesc(principal.getUser().getId())
                .stream()
                .map(this::toBoardResponse)
                .toList();
    }

    public TechnicianJobResponse getMyJob(CustomUserDetails principal, Long workOrderId) {
        WorkOrder wo = requireMyJob(principal, workOrderId);
        return toJobResponse(wo);
    }

    @Transactional
    public TechnicianJobResponse startJob(CustomUserDetails principal, Long workOrderId) {
        WorkOrder wo = requireMyJob(principal, workOrderId);
        requireStatusIn(wo, "Start a job", WorkOrderStatus.NEW, WorkOrderStatus.ASSIGNED, WorkOrderStatus.ON_HOLD);
        WorkOrderStatus from = wo.getStatus();
        if (wo.getStartedAt() == null) {
            wo.setStartedAt(Instant.now());
        }
        wo.setStatus(WorkOrderStatus.IN_PROGRESS);
        wo = workOrderRepository.save(wo);
        logHistory(principal, wo, from, wo.getStatus(),
                from == WorkOrderStatus.ON_HOLD ? "Resumed by technician" : "Started by technician");
        return toJobResponse(wo);
    }

    @Transactional
    public TechnicianJobResponse holdJob(CustomUserDetails principal, Long workOrderId, String note) {
        WorkOrder wo = requireMyJob(principal, workOrderId);
        requireStatusIn(wo, "Put a job on hold", WorkOrderStatus.IN_PROGRESS);
        WorkOrderStatus from = wo.getStatus();
        wo.setStatus(WorkOrderStatus.ON_HOLD);
        wo = workOrderRepository.save(wo);
        logHistory(principal, wo, from, wo.getStatus(),
                note != null && !note.isBlank() ? note : "On hold");
        return toJobResponse(wo);
    }

    @Transactional
    public TechnicianJobResponse completeJob(CustomUserDetails principal, Long workOrderId, String note) {
        WorkOrder wo = requireMyJob(principal, workOrderId);
        requireStatusIn(wo, "Complete a job", WorkOrderStatus.IN_PROGRESS);
        WorkOrderStatus from = wo.getStatus();
        wo.setStatus(WorkOrderStatus.RESOLVED);
        wo.setCompletedAt(Instant.now());
        wo = workOrderRepository.save(wo);
        logHistory(principal, wo, from, wo.getStatus(),
                note != null && !note.isBlank() ? note : "Completed by technician");
        return toJobResponse(wo);
    }

    @Transactional
    public PartResponse logPart(CustomUserDetails principal, Long workOrderId, PartLogRequest request) {
        WorkOrder wo = requireMyJob(principal, workOrderId);
        WorkOrderPart part = partRepository.save(WorkOrderPart.builder()
                .workOrder(wo)
                .name(request.getName().trim())
                .quantity(request.getQuantity())
                .loggedByEmail(principal.getUsername())
                .build());
        return toPartResponse(part);
    }

    @Transactional
    public TimeLogResponse logTime(CustomUserDetails principal, Long workOrderId, TimeLogRequest request) {
        WorkOrder wo = requireMyJob(principal, workOrderId);
        WorkOrderTimeLog log = timeLogRepository.save(WorkOrderTimeLog.builder()
                .workOrder(wo)
                .minutes(request.getMinutes())
                .note(request.getNote())
                .loggedByEmail(principal.getUsername())
                .build());
        return toTimeLogResponse(log);
    }

    @Transactional
    public PhotoResponse uploadPhoto(CustomUserDetails principal, Long workOrderId, PhotoUploadRequest request) {
        WorkOrder wo = requireMyJob(principal, workOrderId);
        try {
            Base64.getDecoder().decode(request.getDataBase64());
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Photo data must be valid base64");
        }
        WorkOrderPhoto photo = photoRepository.save(WorkOrderPhoto.builder()
                .workOrder(wo)
                .fileName(request.getFileName())
                .contentType(request.getContentType())
                .dataBase64(request.getDataBase64())
                .uploadedByEmail(principal.getUsername())
                .build());
        return toPhotoResponse(photo);
    }

    public PhotoDetailResponse getPhoto(CustomUserDetails principal, Long workOrderId, Long photoId) {
        requireMyJob(principal, workOrderId);
        WorkOrderPhoto photo = photoRepository.findById(photoId)
                .filter(p -> p.getWorkOrder().getId().equals(workOrderId))
                .orElseThrow(() -> new EntityNotFoundException("Photo not found"));
        return PhotoDetailResponse.builder()
                .id(photo.getId())
                .fileName(photo.getFileName())
                .contentType(photo.getContentType())
                .dataBase64(photo.getDataBase64())
                .build();
    }

    // ---- helpers ----

    private WorkOrder requireMyJob(CustomUserDetails principal, Long workOrderId) {
        return workOrderRepository.findByIdAndAssignedTechnicianId(workOrderId, principal.getUser().getId())
                .orElseThrow(() -> new EntityNotFoundException("Job not found"));
    }

    private void requireStatusIn(WorkOrder wo, String action, WorkOrderStatus... allowed) {
        for (WorkOrderStatus s : allowed) {
            if (wo.getStatus() == s) return;
        }
        throw new IllegalStateException(action + " is not allowed while the job is " + wo.getStatus());
    }

    private void logHistory(CustomUserDetails principal, WorkOrder wo, WorkOrderStatus from, WorkOrderStatus to, String note) {
        historyRepository.save(WorkOrderStatusHistory.builder()
                .workOrder(wo)
                .fromStatus(from)
                .toStatus(to)
                .note(note)
                .changedByEmail(principal.getUsername())
                .changedByRole(Role.TECHNICIAN.name())
                .build());
    }

    private BoardWorkOrderResponse toBoardResponse(WorkOrder wo) {
        User tech = wo.getAssignedTechnician();
        return BoardWorkOrderResponse.builder()
                .id(wo.getId())
                .code(wo.getCode())
                .title(wo.getTitle())
                .description(wo.getDescription())
                .customerId(wo.getCustomer().getId())
                .customerName(wo.getCustomer().getCompanyName())
                .siteId(wo.getSite().getId())
                .siteName(wo.getSite().getName())
                .priority(wo.getPriority().name())
                .status(wo.getStatus().name())
                .technicianId(tech != null ? tech.getId() : null)
                .technicianName(tech != null ? tech.getFullName() : null)
                .technicianPhone(tech != null ? tech.getPhone() : null)
                .slaDueAt(wo.getSlaDueAt())
                .createdAt(wo.getCreatedAt())
                .updatedAt(wo.getUpdatedAt())
                .build();
    }

    private TechnicianJobResponse toJobResponse(WorkOrder wo) {
        List<StatusHistoryResponse> history = historyRepository.findByWorkOrderIdOrderByChangedAtAsc(wo.getId())
                .stream()
                .map(h -> StatusHistoryResponse.builder()
                        .fromStatus(h.getFromStatus() != null ? h.getFromStatus().name() : null)
                        .toStatus(h.getToStatus().name())
                        .note(h.getNote())
                        .changedAt(h.getChangedAt())
                        .build())
                .toList();

        List<PartResponse> parts = partRepository.findByWorkOrderIdOrderByLoggedAtAsc(wo.getId())
                .stream().map(this::toPartResponse).toList();

        List<TimeLogResponse> timeLogs = timeLogRepository.findByWorkOrderIdOrderByLoggedAtAsc(wo.getId())
                .stream().map(this::toTimeLogResponse).toList();

        List<PhotoResponse> photos = photoRepository.findByWorkOrderIdOrderByUploadedAtAsc(wo.getId())
                .stream().map(this::toPhotoResponse).toList();

        int totalMinutes = timeLogRepository.sumMinutesByWorkOrderId(wo.getId());

        return TechnicianJobResponse.builder()
                .id(wo.getId())
                .code(wo.getCode())
                .title(wo.getTitle())
                .description(wo.getDescription())
                .customerName(wo.getCustomer().getCompanyName())
                .siteName(wo.getSite().getName())
                .siteAddress(String.join(", ", nonBlank(wo.getSite().getAddressLine()), nonBlank(wo.getSite().getCity())).replaceAll("^, |, $", ""))
                .priority(wo.getPriority().name())
                .status(wo.getStatus().name())
                .slaDueAt(wo.getSlaDueAt())
                .startedAt(wo.getStartedAt())
                .completedAt(wo.getCompletedAt())
                .createdAt(wo.getCreatedAt())
                .totalMinutesLogged(totalMinutes)
                .history(history)
                .parts(parts)
                .timeLogs(timeLogs)
                .photos(photos)
                .build();
    }

    private String nonBlank(String s) {
        return s == null ? "" : s;
    }

    private PartResponse toPartResponse(WorkOrderPart p) {
        return PartResponse.builder()
                .id(p.getId()).name(p.getName()).quantity(p.getQuantity())
                .loggedByEmail(p.getLoggedByEmail()).loggedAt(p.getLoggedAt())
                .build();
    }

    private TimeLogResponse toTimeLogResponse(WorkOrderTimeLog t) {
        return TimeLogResponse.builder()
                .id(t.getId()).minutes(t.getMinutes()).note(t.getNote())
                .loggedByEmail(t.getLoggedByEmail()).loggedAt(t.getLoggedAt())
                .build();
    }

    private PhotoResponse toPhotoResponse(WorkOrderPhoto p) {
        return PhotoResponse.builder()
                .id(p.getId()).fileName(p.getFileName()).contentType(p.getContentType())
                .uploadedByEmail(p.getUploadedByEmail()).uploadedAt(p.getUploadedAt())
                .build();
    }
}
