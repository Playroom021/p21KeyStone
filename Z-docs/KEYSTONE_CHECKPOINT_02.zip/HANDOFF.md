# KEYSTONE — Step 2 Handoff (PostgreSQL + Flyway)

## 1. What changed

This step wired the existing entities to a real, versioned PostgreSQL
schema managed by Flyway, and made sure Hibernate can no longer create or
alter the production schema on its own.

- **MySQL check**: confirmed (again) that no MySQL driver, URL, or dialect
  exists anywhere in `pom.xml`, `application.properties`, or any Java
  source. Nothing to remove — the project was already PostgreSQL-only.
- **Flyway added**: `flyway-core` and `flyway-database-postgresql` added
  to `pom.xml` (versions managed by the `spring-boot-starter-parent` BOM,
  Spring Boot 3.3.4 → Flyway 10.x). `flyway-database-postgresql` is
  required separately from Flyway 10 onward.
- **First migration created**: `src/main/resources/db/migration/V1__init_core_schema.sql`
  creates `customers`, `sites`, `app_users`, `work_orders`, and
  `work_order_status_history` — one table per existing entity, with
  column names, types, nullability, uniqueness, foreign keys, and enum
  `CHECK` constraints matching the current `@Entity` classes exactly
  (Spring's default camelCase → snake_case column naming).
- **Hibernate ddl-auto changed**: `spring.jpa.hibernate.ddl-auto` default
  changed from `update` to **`validate`** in the main
  `application.properties`. Hibernate now only checks entity mappings
  against the schema Flyway created at startup and fails fast on drift —
  it never creates, alters, or drops anything against a real database.
- **Env vars added**: `FLYWAY_ENABLED` and `FLYWAY_BASELINE_ON_MIGRATE`,
  documented in `.env.example` alongside the existing DB/JWT variables.
  `JPA_DDL_AUTO` default in `.env.example` updated to `validate`.
- **Test config updated**: `src/test/resources/application.properties`
  now explicitly sets `spring.flyway.enabled=false` and keeps
  `ddl-auto=update` — but only for the in-memory H2 test context. The V1
  migration uses PostgreSQL-only syntax (`BIGSERIAL`, `TIMESTAMPTZ`), so
  it doesn't run against H2; letting Hibernate build the test schema from
  entities is the least-scope way to keep `mvn test` working without a
  real PostgreSQL instance. This does **not** affect production, where
  Flyway owns the schema and `ddl-auto` is `validate`.
- **README updated**: new Flyway explanation under "Create the database",
  `db/migration/` added to the project layout, stack line mentions
  Flyway.

No JWT/auth logic, work-order lifecycle, Parts, TimeLog, SLA fields,
React, or dashboard work were touched — out of scope per this step, and
none of those tables/columns exist yet, by design.

## 2. Files changed

| File | Change |
|---|---|
| `pom.xml` | Added `flyway-core`, `flyway-database-postgresql` |
| `src/main/resources/application.properties` | `ddl-auto` → `validate`; added `spring.flyway.*`; added `spring.jpa.open-in-view=false` |
| `src/main/resources/db/migration/V1__init_core_schema.sql` | **New** — first migration, core schema |
| `.env.example` | Added `FLYWAY_ENABLED`, `FLYWAY_BASELINE_ON_MIGRATE`; `JPA_DDL_AUTO` default → `validate` |
| `src/test/resources/application.properties` | Added `spring.flyway.enabled=false` (H2 test context only) + explanatory comment |
| `README.md` | Flyway section under DB setup, project layout, stack line |
| `HANDOFF.md` | This file |

No controllers, services, repositories, entities, DTOs, security classes,
or frontend files were modified.

## 3. Database setup

Schema is created by Flyway, not Hibernate, not manually:

```sql
CREATE DATABASE authapp_db;
```

On startup, Spring Boot runs Flyway automatically against
`spring.datasource.*`, applying every file in
`src/main/resources/db/migration` in order and recording progress in a
`flyway_schema_history` table it creates itself. Currently there is one
migration: `V1__init_core_schema.sql`, creating `customers`, `sites`,
`app_users`, `work_orders`, `work_order_status_history` with FKs, unique
constraints, indexes on FK columns, and `CHECK` constraints for the
`Role`, `Priority`, and `WorkOrderStatus` enums.

`spring.jpa.hibernate.ddl-auto=validate` means Hibernate never writes DDL
against this database — it only confirms the entities match what Flyway
built, and fails startup loudly if they don't.

**Rule for the future**: never edit `V1__init_core_schema.sql` once it has
run anywhere (dev, CI, prod). Add a new `V2__<description>.sql` for any
further schema change.

## 4. Commands to run

```bash
# 1. Config
cp .env.example .env
export $(grep -v '^#' .env | xargs)

# 2. Create the (empty) database once
psql -U postgres -c "CREATE DATABASE authapp_db;"

# 3. Build
mvn clean package

# 4. Test
mvn test

# 5. Run — Flyway migrates the schema automatically on startup
mvn spring-boot:run
# or
java -jar target/authapp-1.0.0.jar
```

To run just the migration without starting the app (useful for CI/manual
checks), the Flyway CLI or Maven plugin can be pointed at the same
`db/migration` folder and datasource; no CLI/plugin was added to `pom.xml`
in this step since Spring Boot's own auto-run-on-startup covers the
stated task ("run Flyway migration" = start the app and let it run).

## 5. Test result

**⚠️ Disclosed plainly, as in the Step 1 handoff:** this sandbox has no
Maven installed and no outbound network access (`apt-get install maven`
was attempted and failed with `403 Forbidden` on every package — this is
a proxy/environment restriction, not a code issue), so `mvn clean
package`, `mvn test`, `mvn spring-boot:run`, and an actual Flyway
migration run against a live PostgreSQL instance could **not** be
executed here.

What was verified manually instead:
- `pom.xml` is well-formed XML (parsed successfully).
- The migration SQL has balanced parentheses, five `CREATE TABLE`
  statements (one per entity) and seven `CREATE INDEX` statements, table
  creation ordered so every `REFERENCES` target already exists
  (`customers` → `sites` → `app_users` → `work_orders` →
  `work_order_status_history`).
- Every migration column, type, nullability, and constraint was checked
  line-by-line against the corresponding `@Entity` field/annotation
  (`Customer`, `Site`, `User`, `WorkOrder`, `WorkOrderStatusHistory`) to
  confirm they match what Hibernate would expect at `ddl-auto=validate`
  time, including the default Spring camelCase → snake_case column
  naming and existing `@Table(name = ...)` overrides (`app_users`).
- Grepped all `.java`/`.properties`/`.xml` files again for `mysql` —
  none found.
- Confirmed no other file references `ddl-auto`, `flyway`, or
  `datasource` outside the two `application.properties` files.

**The next developer must run `mvn clean package`, `mvn test`, and then
`mvn spring-boot:run` against a real local PostgreSQL instance
immediately after unpacking this checkpoint**, and confirm:
1. Flyway logs show `V1__init_core_schema` applying successfully to an
   empty `authapp_db`.
2. The app starts with no Hibernate validation errors (would indicate a
   mismatch between the migration and the entities).
3. `mvn test` passes using the H2/no-Flyway test path.

Treat this as the first step of the next session, exactly as the Step 1
handoff did — and this time, please report back whether it passed, since
two checkpoints in a row have now shipped unverified by an actual Maven
run.

## 6. Known issues

- **Build/migration/tests unverified end-to-end** (see above) — same
  caveat as Step 1, still unresolved because this environment has neither
  Maven nor network access. This is the top priority for the next
  developer to close out.
- The H2 test context does not exercise the Flyway migration at all
  (`spring.flyway.enabled=false` there) — it builds its schema from
  entities via `ddl-auto=update` instead. So a passing `mvn test` does
  **not** by itself prove the migration SQL is correct against real
  PostgreSQL; only an actual `mvn spring-boot:run` against Postgres (or a
  Testcontainers-based test, not added here — out of scope) proves that.
  This is a real gap, not just an unverified claim, and should be closed
  before Step 3 adds more schema.
- `spring.flyway.baseline-on-migrate=false` assumes every target database
  starts empty. If Step 2 is ever applied to a database that already has
  hand-created tables from the old `ddl-auto=update` behavior, Flyway
  will refuse to run until either the tables are dropped or
  `baseline-on-migrate`/`flyway baseline` is used deliberately — don't
  flip that default without understanding why first.
- `app.jwt.secret` still has a placeholder default in
  `application.properties`, unchanged from Step 1 — still must be
  overridden via `JWT_SECRET` outside local dev.

## 7. What the next step should do

1. **First**, actually run the verification in section 5 against a real
   PostgreSQL instance and fix anything that doesn't match — do not start
   new schema work on an unverified migration.
2. Only after that's confirmed green, pick up the next feature slice
   (work-order lifecycle, Parts, TimeLog, SLA, JWT/auth changes,
   dashboard, or React frontend — whichever is next in the project plan)
   as its own migration file (`V2__...`), never by editing `V1`.
3. If/when integration tests are added that need a real Postgres (e.g.
   via Testcontainers), that's a good moment to also add a Flyway
   Maven-plugin binding so `mvn verify` can validate migrations directly,
   independent of the app boot path.
