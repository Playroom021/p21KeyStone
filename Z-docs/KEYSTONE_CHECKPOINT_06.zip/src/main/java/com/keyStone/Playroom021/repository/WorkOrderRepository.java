package com.keyStone.Playroom021.repository;

import com.keyStone.Playroom021.entity.WorkOrder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Optional;

public interface WorkOrderRepository extends JpaRepository<WorkOrder, Long>, JpaSpecificationExecutor<WorkOrder> {

    // Ownership-scoped lookups: a customer can only ever fetch their own work orders,
    // by construction of the query itself, not by an after-the-fact permission check.
    List<WorkOrder> findByCustomerIdOrderByCreatedAtDesc(Long customerId);

    List<WorkOrder> findByCustomerIdAndStatusOrderByCreatedAtDesc(Long customerId, com.keyStone.Playroom021.entity.WorkOrderStatus status);

    Optional<WorkOrder> findByIdAndCustomerId(Long id, Long customerId);

    // Same idea, for a TECHNICIAN: a work order they are not assigned to simply doesn't match.
    Optional<WorkOrder> findByIdAndAssignedTechnicianId(Long id, Long technicianId);

    long countByCustomerId(Long customerId);

    boolean existsByCustomerId(Long customerId);

    boolean existsBySiteId(Long siteId);

    // Step 5: fetch customer/site/assignedTechnician in the same query so the paged
    // Work Order API doesn't issue extra queries per row when rendering names.
    @Override
    @EntityGraph(attributePaths = {"customer", "site", "assignedTechnician"})
    Page<WorkOrder> findAll(Specification<WorkOrder> spec, Pageable pageable);
}
