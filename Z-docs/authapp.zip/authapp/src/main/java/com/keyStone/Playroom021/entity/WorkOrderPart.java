package com.keyStone.Playroom021.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

/** A part/material a technician logged as used on a work order. */
@Entity
@Table(name = "work_order_parts")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkOrderPart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "work_order_id", nullable = false)
    private WorkOrder workOrder;

    @Column(nullable = false, length = 150)
    private String name;

    @Column(nullable = false)
    private Integer quantity;

    @Column(length = 150)
    private String loggedByEmail;

    @Column(nullable = false, updatable = false)
    private Instant loggedAt;

    @PrePersist
    protected void onCreate() {
        this.loggedAt = Instant.now();
    }
}
